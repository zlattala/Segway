#ifndef ROBOCALC_DATATYPES_H_
#define ROBOCALC_DATATYPES_H_

#include <string>
#include <set>
#include <tuple>
 

#endif
